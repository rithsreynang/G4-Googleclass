const express = require('express');
const taskModels = require('./models/task_model');
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended:false }))

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
});
app.get('/', (req, res) => {
    // TODO
    
});
/**
 * Description: CRUD posts
 * Endpoint: /api/posts
 */

// Get posts
app.get('/api/posts', (req, res) => {
    // TODO
    const tasks = load();
    const task = taskModels.getAllTasks();
    res.json(task);

});

// Get post
app.get('/api/posts/:id', (req, res) => {
    // TODO
    const tasks =load();
    const task = taskModels.showAllTasks(parseInt(req.params.id));
    res.send(task);
});

// Create a new post
app.post('/api/posts', (req, res) => {
    // TODO
});

// Delete post
app.delete('/api/posts/:id', (req, res) => {
    // TODO
    const task = taskModels.deleteTask(parseInt(req.params.id));
    if (!task) {
        res.status(404).json({ success: false, message:` can't find task ID ${req.params.id} `})
    }
    res.status(200).json({ success: true, message: "Task delete already" });
})

// Update a post
app.put('/api/posts/:id', (req, res) => {
    // TODO
});


