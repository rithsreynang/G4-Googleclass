const { json } = require('express');
const fs = require('fs');
function load() {
    return json.parse(fs.readFileSync("posts.json"));
}
function save(data) {
    fs.writeFileSync("posts.json", JSON.stringify(data));
}

function getAllTasks() {
    const tasks = load();
    const task = tasks.filter(tasks => tasks.id === id);
    return task;
}


function showAllTasks(id) {
    const tasks = load();
    const task = tasks.find(task => tasks.id === id);
    return task;
}

function deleteTask(){
    axios.delete(url + "/task/" + taskId)
    .then(response => {
        console.log("Task deleted:", response.data.data);
        getAllTasks();
    })
    .catch(err => {
        console.error("Error deleting task:", err);
    });
}
module.exports.getAllTasks = getAllTasks;
module.exports.showAllTasks = showAllTasks;
module.exports.deleteTask = deleteTask;