const container = document.querySelector('#container');
function getUsers(res) {
   // TODO
   let buttons= document.querySelectorAll('button');
   console.log(1);


}

// TODO with axios.get() ...