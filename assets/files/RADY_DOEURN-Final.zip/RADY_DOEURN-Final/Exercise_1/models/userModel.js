const fs = require('fs');


function load() {
    return JSON.parse(fs.readFileSync("tasks.json"));
}

function save(data) {
    fs.writeFileSync("tasks.json", JSON.stringify(data));
}

