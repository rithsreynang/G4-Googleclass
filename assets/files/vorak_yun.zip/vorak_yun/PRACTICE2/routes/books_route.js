const express = require('express');

let router = express.Router();
let books = [
    { id: 1, title: "The Lord of the Rings", author: "Tolkien" },
    { id: 2, title: "Hamlet", author: "Shakespeare" },
    { id: 3, title: "Harry Potter", author: "Rowling" },
    { id: 4, title: "Romeo and Juliet", author: "Shakespeare" },
    { id: 5, title: "The Odyssey", author: "Homer" }
];

// TODO: DEFINE THE 4 ROUTES HERE

// Get all the books
router.get("/getBooks", (req, res) => {
    res.status(200).send(books)
})

// Create a new book
router.post("/createBook", (req, res) => {
    //get last id
    let lastId = books[books.length-1].id
    // create new id
    let currentId = lastId + 1
    // create new books
    let newBook = { id: currentId, title: req.body.title, author: req.body.author }
    books.push(newBook)
    //send list books
    res.status(200).send(books)

})

// Update one book by id
router.put("/updateBook/:book_id", (req, res) => {
    // id to update
    let id = Number(req.params.book_id);
    // find id in list 
    let index = books.findIndex(book => book.id === id)
    // new data for update
    let newBook = { id: id, title: req.body.title, author: req.body.author }
    //update data in array
    let isFound = false
    let message = "Id not found"
    if (index > -1) {
        isFound = true
        books.splice(index, 1, newBook);
    }
    // send list of books or message to the client
    if (isFound){
        res.status(200).send(books)
    }else{
        res.status(200).send(message)
    }
})

// Delete books by author
router.delete("/deleteBook", (req, res) => {
    //get author
    let author = req.query.author
    // get index of book 
    let index = books.findIndex(book => book.author === author)
    // to delete data in array
    let isFound = false
    let message = "Author not found"
    if (index > -1) {
        isFound = true
        books.splice(index, 1);
    }
    // send list of books or message to the client
    if (isFound){
        res.status(200).send(books)
    }else{
        res.status(200).send(message)
    }
})

module.exports = router;