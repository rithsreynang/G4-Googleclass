
const BASE_URL = "http://localhost:3000/";

function getName() {
  // YOUR CODE HERE
  const HTTP_REQUEST_DATA = BASE_URL+"getName"
  let value = document.querySelector("#prodId").value
  console.log(value)
  axios.get(HTTP_REQUEST_DATA,{
    params:{
      id: value
    }
  }).then( (response) => {result.textContent = response.data})
  .catch((err) => ( console.log(err)))
}

function getBrand() {
  // YOUR CODE HERE
}

const result = document.querySelector("#result");

const getNameButton = document.querySelector("#getName");
getNameButton.addEventListener("click", getName);

const getNameBrand = document.querySelector("#getBrand");
getNameBrand.addEventListener("click", getBrand);
