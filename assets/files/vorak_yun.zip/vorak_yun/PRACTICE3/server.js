const express = require("express");
const fs = require("fs");
const app = express();
const PORT = 3000;
app.listen(PORT);
app.use(express.static("public"));

// YOUR CODE HERE

function read (){
    let data = fs.readFileSync("data.json")
    return JSON.parse(data)
}

app.get("/getName", (req,res) => {
    console.log(req.query.id)
    let id = Number(req.query.id)
    let products = read()
    let index = products.findIndex( product => product.id === id)
    res.status(200).send(products[index].name)
})


