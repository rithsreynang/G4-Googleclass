// #2 - API URL 

const API_URL = "https://randomuser.me/api";

axios.get(API_URL)
  .then(response => {
    // Your code here...
    displayData(response.data.results[0]) 
  })
  .catch(err => {
    console.log(err);
  })

function displayData (person) {
  //image
  image.src = person.picture.large

  //gender
  gender.textContent = person.gender

  //number phone 
  phone.textContent = person.cell

  // title and background color
  if (person.name.title === "Mr"){
    cardContainer.style.backgroundColor = "teal"
  }else if (person.name.title === "Mrs"){
    cardContainer.style.backgroundColor = "purple"
  }else if (person.name.title === "Miss"){
    cardContainer.style.backgroundColor = "pink"
  }else{
    cardContainer.style.backgroundColor = "#0b0a2c"
  }
  // title 
  title.textContent = person.name.title
  // first name
  firstname.textContent = person.name.first

  // last name
  lastname.textContent = person.name.last
}

/**
 * Main 
 * 
 */
const cardContainer = document.querySelector('.card-container');
const firstname = document.querySelector('.firstname');
const lastname = document.querySelector('.lastname');
const title = document.querySelector('.title');
const image = document.querySelector('img');

const phone = document.querySelector('.phone');
const gender = document.querySelector('.gender');