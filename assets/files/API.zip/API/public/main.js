let ul= document.querySelector('.ul');
let url = "http://localhost:2000";
let i = 0;

function deleteBook(e){
    let id = e.target.id;
    axios.delete("/delete/book/" + id).then((req, res)=>{
        location.reload()
        
    })
}


function displayBook() {
    axios.get(url + "/book").then(res => {
        let data = res.data.data;
        data.forEach(element => {
            let li = document.createElement("li");
            let title = document.createElement("p");
            title.textContent = element.title;
            let btn = document.createElement("button");
            btn.id = i;
            btn.textContent = "Delete";
            btn.addEventListener("click", deleteBook);
            li.appendChild(title)
            li.appendChild(btn)
            ul.appendChild(li);
            i++;
        });
    })
}
function addBook(){
    let input = document.querySelector("input");
    let book = {"title": input.value};
    axios.post(url + "/create/book", book).then((res)=>{
        location.reload()
        displayBook()
    })
}
let add = document.querySelector("button");
add.addEventListener("click", addBook)
displayBook();