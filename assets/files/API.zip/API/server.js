const express = require("express");
const fs = require("fs");
const { domainToASCII } = require("url");
const app = express();
const PORT = 2000;
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.listen(PORT, (e)=>{
    console.log("SERVER IS RUNNING...");
})
function save(){
    fs.writeFileSync("database.json", JSON.stringify(data));
}

let data = JSON.parse(fs.readFileSync("database.json"));
app.get("/book", (req, res)=>{
    res.json({status: 200, message: "get list of book successfully", data: data})
})
app.post("/create/book", (req, res)=>{
    let book = req.body;
    data.push(book);
    save()
    res.json({status: 200, message: "request success", data : data})
})

app.delete("/delete/book/:id",(req, res)=>{
    let id = req.params.id;
    if (data.length > id){
        data.splice(id, 1);
        save();
        res.json({status: 200, message: "Delete Successfully"});
    }else{
        res.json({status: 404, message: "Book can not delete and found"})
    }
})